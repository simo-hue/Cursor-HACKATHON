---
title: "Brief - Coding Agent Hackathon"
source: "https://cursor-hackathon.yellowtest.it/dashboard"
author:
published:
created: 2026-06-13
description: "Coding Agent Hackathon powered by Cursor - build an agentic company brain over simulated company APIs + RAG. Cursor x Yellow Tech."
tags:
  - "clippings"
---
Welcome, simone/13.06.2026 - Milano

## The challenge in one page.

Build an agentic company brain: an endpoint that orchestrates our simulated company APIs (CRM, ERP, call logs) and a RAG you build over the provided documents, to answer hidden questions and produce artifacts. The core is orchestration, not a single prompt.

Your credentials

## Everything you need to build

Two credentials, both assigned to you automatically: Cursor credits for the IDE, and an API key your deployed brain uses to call our Al Dente mock API.[Cursor credits](https://cursor-hackathon.yellowtest.it/cursor)

[

Redeem your Cursor link

Open your Credits link while logged into Cursor to add the credits to your account.

Open](https://cursor-hackathon.yellowtest.it/cursor)[

API key

Call the company APIs

Your bearer key for the Al Dente mock API (CRM, ERP, call logs, docs) - it also identifies you for the efficiency score.

Open](https://cursor-hackathon.yellowtest.it/api-key)

What you build

## Four deliverables, one system

The heart of the challenge is orchestration: an agent loop that understands which tools it needs, combines our APIs with a RAG you build, and formats the requested output. You win by iterating, not by pasting a prompt.

01

The agent (the brain)

A loop that receives the request, decides which sources it needs, makes targeted API calls, queries your knowledge base and composes the answer or the artifact.

02

The knowledge base (RAG)

You build it over the provided documents. It is one of the agent's tools, next to the APIs.

03

The public endpoint

POST /ask with the starter's frozen schema. It is what the evaluation system queries.

04

A working UI with a knowledge graph

Works end-to-end and includes a graph visualization of customers, suppliers, products and materials.

Your data sources

## Where the facts live

The only data sources are the ones we provide: no invented or external data. The APIs are read-only and require the Authorization header with your token. Your calls are counted server-side - the right targeted call beats downloading everything. Full reference in API.md.

CRM

Customers, opportunities, orders, invoices. Structured data with filters.

Call logs

Calls with full transcripts: long text, to be extracted surgically (search / pagination) instead of downloaded whole.

ERP / production

Lots, inventory, suppliers, bills of materials (BOM), shipments.

Knowledge base

Company documents to RAG over: product specs and allergens, returns / quality policies, customer requirements, price list. Shipped in backend/data/kb/.

The rules of the game

## What is fixed, what is free

Fixed

- The endpoint schema: POST /ask with { question } -> { answer, sources, verticale, artifact\_url? }, already wired in the starter.
- Our APIs are read-only and require the auth header.
- The only data sources are the ones we provide: no invented or external data.

Free

- The agent architecture and orchestration strategy.
- The LLM: any model on Regolo.ai or Mistral (free tier).
- How you build the RAG.
- The UI design, stack and layout - the graph view is required, the look is yours.
- How you optimize your calls.

How scoring works

## Three levels. One ranking.

An LLM judge anchored to a correction key scores each hidden question on completeness. Efficiency breaks ties. Human review rates the artifacts. A final pitch decides the podium. Latency has a generous ceiling, not a hard cutoff - but slow loops cost efficiency.

Completeness

Primary axis. Did the answer cover the facts in the correction key (must-contain), pulled from the right sources?

Efficiency

Tie-breaker. Fewer API calls, less data downloaded, faster responses - measured server-side via your mock-API token.

Honesty

Traps reward honest abstention. "I don't have this data" beats a fabricated figure - hallucinations are penalized.

Artifacts

Generation tasks return HTML/markdown inline, or a docx/pptx/pdf/xlsx file via artifact\_url. Facts are judged automatically; style is scored by humans (Level 2).

From build to submission

## Test, deploy, submit

Two tools to verify, throughout the day, that your system answers correctly - and a single deadline to hit.

Self-test

Test in a loop

12 sample requests with answers (SAMPLE\_QUESTIONS.md), plus the platform self-test: a battery against your deployed endpoint that returns a score with feedback. See where you fail, fix, rerun. An endpoint check validates the /ask contract (schema, no-auth, latency) before you submit.

Deploy

Railway, single service

Free for the day ($5 trial, no credit card). You don't write a Dockerfile: Railway builds on its own (Railpack + the railway.json in the starter). Step-by-step in DEPLOY.md. Do your first deploy around hour 3, not in the last hour.

What you submit

URL, repo, description

The public URL of your endpoint, your code repo and a short (~200 word) description of your approach. Deadline 17:00. If your app is unreachable when the automated evaluation starts, you lose the Level 1 points - deploy early.

The day

## 9:30 to 20:00, Milano

Saturday, June 13th 2026. Six hours of work, submission by 17:00. Internal timings may shift slightly on the day.

9:30 - 10:00

Meetup and coffee

10:15 - 11:00

Kickoff and intro (plenary briefing, Q&A)

11:00 - 13:30

Build time

13:30 - 14:30

Lunch break (self-service)

14:30 - 17:00

Build time. Submission by 17:00

17:00 - 18:30

Judging (automated evaluation + jury review)

18:30 - 19:00

Pitch time for the top 3

19:00 - 19:30

Winners announcement and awards

19:30 - 20:00

Networking aperitivo

Strategy

## How the winners play it

None of this is required - but it is what separates a working brain from a top one.

MVP first

Get the agent answering one simple request end-to-end, then extend to more sources and to the traps.

Routing

The value is in understanding which source is needed. Design the agent to choose well.

Pagination

List endpoints return 50 items by default. For aggregates check pagination.total and page through.

Arithmetic in code

Do sums and counts in Python, not in the prompt.

Surgical extraction

On long transcripts don't download everything - search for the useful part.

Latency as a constraint

A loop with many calls is slow. Balance depth and time: each answer must arrive within 30 seconds.

Self-test in a loop

It is the fastest way up the leaderboard. The people who run this cycle most end up highest.

Deploy early

Surface infrastructure issues with hours of buffer, not in the last hour.

Rules

## The non-negotiables

Individual: you work alone.

GitHub allowed but not required - the deploy goes via CLI.

Runtime model via Regolo.ai or Mistral (free tier).

The only data sources are our APIs and the provided documents.

The endpoint schema must stay exactly as in the starter.

FAQ

## Before you ask

Do I need to know how to code?

Yes, it is a technical challenge. Cursor and a frontier LLM accelerate you a lot, but you need solid architectural judgment.

Can I use any model?

Any model on Regolo.ai or Mistral (free tier) that supports tool calling. List the live ones with GET {LLM\_BASE\_URL}/models and pick one - choosing well is part of the challenge.

Does the UI count for the score?

Yes. It must work end-to-end and include a knowledge graph of the company's materials. For the top projects the jury grades how usable and polished it is, the graph view and the overall wow factor (Level 2).

What happens if the agent invents a fact?

Penalty. Better to answer "not available" when the information is not in the sources - some requests are traps.

How do I deliver docx / pptx / pdf / xlsx files?

Your backend generates them and serves them from /files/; the response schema has the artifact\_url field. The pattern is already wired in the starter.

Can I add libraries or change the stack?

Yes, as long as the endpoint schema stays as in the starter and the app deploys to Railway.

Ready