---
title: "API key - Coding Agent Hackathon"
source: "https://cursor-hackathon.yellowtest.it/api-key"
author:
published:
created: 2026-06-13
description: "Coding Agent Hackathon powered by Cursor - build an agentic company brain over simulated company APIs + RAG. Cursor x Yellow Tech."
tags:
  - "clippings"
---
## Your API key.

This is the key your deployed company brain uses to call our Al Dente mock API (CRM, ERP, call logs, documents). It's generated for you automatically - no setup, just send it as a bearer token.

Ready to use

No redemption, no signup. Put it in your agent's.env and send it as Authorization: Bearer on every call to the mock API.

It's also your identity

The mock API reads who you are from this key, so your calls, data downloaded and latency feed your efficiency score. Don't share it - someone else's calls would land on you.

Keep it private

Don't paste it in commits, public Slack/Discord or screenshots. It is not the key your agent exposes to the evaluator - your /ask endpoint stays public, no auth.

Base URL

https://aldente.yellowtest.it

API key

`eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOCIsImtpbmQiOiJtb2NrX2FwaSJ9.BS34xq-46XQx9Py0IgBi6cAdDimG6L-9H7wOyhXVq58`

```
ALDENTE_API_BASE_URL=https://aldente.yellowtest.it
ALDENTE_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxOCIsImtpbmQiOiJtb2NrX2FwaSJ9.BS34xq-46XQx9Py0IgBi6cAdDimG6L-9H7wOyhXVq58
```

```
curl https://aldente.yellowtest.it/crm/customers \
  -H "Authorization: Bearer $ALDENTE_API_KEY"
```

Every call to the Al Dente API needs the `Authorization: Bearer` header. See the API reference in the starter kit for the full list of endpoints.