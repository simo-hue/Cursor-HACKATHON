---
title: "FAQ - Coding Agent Hackathon"
source: "https://cursor-hackathon.yellowtest.it/faq"
author:
published:
created: 2026-06-13
description: "Coding Agent Hackathon powered by Cursor - build an agentic company brain over simulated company APIs + RAG. Cursor x Yellow Tech."
tags:
  - "clippings"
---
## Everything you'd ask before raising a hand.

Setup, the /ask contract, the submission flow, scoring. If something breaks during the day this is the first place to look.

01 / The hackathon

## The hackathon.

What this event is, who can join, how the day works.

- What is the Company Brain challenge?
	A one-day coding hackathon hosted by Yellow Tech, powered by Cursor. Each participant builds the **company brain** of **Al Dente S.r.l.**, a fictional pasta maker: an agent that answers questions about the company by orchestrating our simulated CRM, ERP and call-log APIs together with a RAG you build over the provided documents, and that also produces artifacts (HTML/markdown, or docx/pptx/pdf/xlsx files). We score it in two automated/human stages plus a final pitch.
- Registration is **open**: create an account with any email address. There is no domain restriction.
	Mentors and judges receive their accounts directly from the organisers and don't self-register.
- Can I work in a team?
	No - the format is **individual**. One account, one submission, one person. You can chat with neighbours, but the company brain you submit has to be your own work.
- How is the day structured?
	Check-in and a plenary briefing in the morning, then a **6-hour build window** with a hard submission cut-off. After the cut-off the automated evaluator runs while the jury inspects the top entries; the top three then give a short live pitch and the jury picks the final podium. Indicative timing: build session 11:00-17:00 (submit by 17:00), pitches and awards in the evening.
- What are the prizes?
	1st place **1,000 EUR**, 2nd place **500 EUR**. The podium is decided by the final live pitch among the top three.

02 / Setup & tools

## Setup & tools.

Cursor, Docker, Railway. What changes by operating system.

- How do I set up Cursor?
	macOSWindowsLinux
	Install **Cursor** (cursor.com) on macOS, Windows or Linux and sign in with an individual account. We provide Cursor credits for the event: each participant gets a Credits link on the **Cursor credits** page - open it while logged into Cursor to add the credits to your account. Cursor is the coding environment: it writes and edits your code. It is separate from the runtime LLM your deployed brain calls (see section 03).
	We recommend against running an agent fully unattended with all guardrails off: an agent looping without review can spiral into changes you didn't intend.
- Which model should I use inside Cursor?
	Pick a strong frontier coding model in Cursor (the latest Claude or GPT class). This is the model that helps you *write code* - it is independent from the model your deployed company brain uses at runtime.
- Do I need Docker?
	macOSWindowsLinux
	It helps. Docker gives you a fast local loop and parity with the deploy environment - Docker Desktop on macOS/Windows, Docker Engine on Linux. On Windows the Docker Desktop installer needs the WSL2 backend. The starter ships a `docker-compose` fallback.
	If you can't install it (corporate laptop, old machine), you can still run natively (`uv` for the backend, `pnpm` for the frontend) and deploy on Railway.
- Do I need a Railway account? Credit card?
	Yes for the account, no for the credit card. Railway's free tier is enough for the build day and doesn't require billing details. Sign up before you arrive so you don't lose time on email verification on the day.
- Can I deploy on Vercel / Render / Fly / something else?
	Yes. The contract is a public HTTPS URL exposing `POST /ask`. We default the docs to Railway because it's the fastest path; any host that gives you a public endpoint works.
- Can I work offline?
	Practically no. Cursor, the runtime LLM, our mock API, the deploy host and this platform all need connectivity. Wi-Fi credentials are posted on-site.

03 / Runtime LLM access

## Runtime LLM access.

The model your deployed brain calls - separate from Cursor.

- What's the difference between Cursor and the runtime LLM?
	Two different things. **Cursor** is your coding assistant - it writes the code on your laptop. The **runtime LLM** is the model your *deployed* company brain calls to reason over the API data and the RAG and to draft answers and artifacts. They are billed and configured separately.
	Runtime LLM access goes through **Regolo.ai** or **Mistral** (free tier, OpenAI-compatible APIs): you create the account, generate your key and put it in your app's `.env`. Details in the starter kit.
- Which runtime model can I use?
	Any model available on Regolo.ai or Mistral (free tier). The starter lists the models we verified for tool calling. Use a cheaper model for high-volume paths (classification, extraction, embeddings) and reserve a stronger model for the final answer or the artifact. We score the answers, not the model.
- How much runtime budget do I get?
	Both providers offer a free tier that covers a 6-hour build day if you cache, batch and avoid runaway loops (mind Mistral's ~1 req/s rate limit). The efficiency score rewards lean agents, so spending less is also a scoring advantage, not just a budget one.
- Where do my credentials go? Can I leak them?
	Runtime LLM credentials go in your deployed app's `.env`, never in Cursor and never in a commit, screenshot or shared chat. Same for your mock-API token. If you think a credential leaked, tell an organiser and we'll rotate it.

04 / Starter & /ask contract

## Starter & /ask contract.

What ships in the starter zip, and the rules /ask must follow.

- What's in the starter zip?
	A FastAPI backend skeleton with the `/ask` route wired but unimplemented (it returns `501` until you build the agent loop), the mock-API reference (endpoints, filters, auth), and the company **knowledge base documents** (spec sheets, allergens, quality and returns policies, GDO specs, price lists) to index into your RAG. Plus `railway.json`, a `docker-compose` fallback and the Cursor rules. The latest version is served from `/static/company-brain-starter.zip`.
- Can I rewrite the backend in another language / stack?
	Yes. The only constraint is the `/ask` contract below. Use Python, Node, Go, Rust, Elixir - whatever you ship fastest. We score the answers, not the stack.
- Can I add extra data or scrape more sources?
	No external or invented data. The only sources are our mock API and the documents we ship. The challenge is orchestrating *those* sources well - inventing facts is penalized. You are free to enrich your RAG with the provided documents however you like (chunking, embeddings, indexes).
- Hard rules for /ask: what's locked?
	The contract is frozen. Your `POST /ask` must:
	- Live at the **root path** `/ask` - no `/api/ask`, `/v1/ask`, etc.
	- Accept POST with a JSON body containing `question` (string).
	- Return a JSON **object** directly with `{ answer, sources, verticale }`. No `{"data": ...}` wrapper.
	- A few generation questions ask for a **binary document** (docx / pptx / pdf / xlsx): generate the file, serve it from your own backend (e.g. a `/files/` static route - no external storage needed) and return its URL in the optional `artifact_url` field. We download it and judge the facts inside; the jury rates the look.
	- Be reachable **without auth**. No bearer token, no API key header.
	- Reply in a **single round-trip**. No streaming (SSE / NDJSON / `stream=True`), no async `job_id` + poll.
	- Reply within the per-question time budget of **30 seconds**. The endpoint check reports your latency so you can tune it.
	- Set `Content-Type: application/json`. FastAPI does this for free if you `return {...}`.
	Other endpoints (debug, admin, frontend-internal) are entirely up to you - the rules only apply to `/ask`.
- What goes in \`verticale\`?
	Exactly one of: `crm`, `erp`, `calls`, `kb` - the primary source your answer draws on. The evaluator checks the value against the question's expected source. If you can't classify confidently, return your best guess - it's better than an empty string.
- How do I authenticate against the mock API?
	Your dashboard shows a personal **mock-API token**. Send it as a bearer credential on every call to the Al Dente API. It also identifies you, so we can log your calls, the data you download and your timing - the inputs to your efficiency score. Note the direction: the mock API needs your token, but your own `/ask` must stay auth-free.

05 / Pre-submit checks

## Pre-submit checks.

Free endpoint check + dry-run with full eval (2 attempts, 30-min cooldown).

- How do I test my brain without spending a dry-run?
	Use the **12 sample questions**. They ship with answers inside the starter zip (`SAMPLE_QUESTIONS.md`) and are also browsable on the `/sample-questions` page once you're logged in. They span all four sources and the question types you'll be scored on (lookup, aggregate, multi-source, trap, generation), so you can iterate against known-good answers as much as you want - no quota, no cost.
	They show the *shape, balance and difficulty* of the challenge, not the exact questions: the hidden evaluation set is larger and entity-disjoint. Get these right locally first, then spend a dry-run to see how you score on unseen questions.
- What does the Submit page check before I submit?
	Two separate steps, with very different costs and quotas.
	- **Step 1 - Endpoint check**. One HTTP round-trip against your `/health` and `/ask`. Validates shape, status, content-type and latency. No LLM, no score. **Unlimited**: retry as you fix.
	- **Step 2 - Dry-run**. A full evaluator pass on a stratified sample of 16 questions (4 per source), with the LLM judge scoring each answer. Returns a per-source breakdown plus an LLM-generated narrative and a Cursor prompt you can paste back into your editor. **2 attempts + 30-min cooldown** between runs.
	Mentors and admins are exempt from both the cap and the cooldown. The actual *submit* still has to come from a participant account.
- Why does the dry-run have a 2-attempt cap and a 30-min cooldown?
	Each dry-run hits an LLM judge 16 times - it's the most expensive thing the platform does on your behalf. The cap keeps total spend predictable across all participants, and the cooldown forces a pause so you redeploy and improve instead of spamming the button. The endpoint check above stays free precisely so you can iterate on the contract without burning dry-runs.
- I used both dry-runs and my brain still scores low.
	Submit anyway when you're ready - the real L1 evaluator runs on your URL regardless of dry-run outcomes, on a different (full) question set. The endpoint check is still free if you want to verify the contract one more time before submit. A mentor can also trigger an extra dry-run for you while debugging.
- I clicked Run dry-run but no attempt was consumed. Why?
	The dry-run does an inline contract check before scheduling the LLM judge. If the contract check fails (endpoint unreachable, wrong shape, wrong status), the dry-run aborts and the attempt is **not** consumed - it would be wasted spend. Fix the contract with Step 1, then re-run.
- The endpoint check says my response Content-Type is wrong.
	Set `Content-Type: application/json`. If you're using FastAPI and you `return {...}` from the route handler, you get this for free. If your framework defaults to `text/html`, configure the JSON serializer or set the header manually.

06 / Submission

## Submission.

One-shot policy, the source-code zip, what's locked once submitted.

- Why is the submission one-shot? Can I edit it?
	Once you click Submit, your URLs, description and source zip are locked - no edits, no replacements. The one-shot rule keeps everyone on the same playing field and prevents last-minute deploy chaos eating into the evaluation window. Test on `/submit` before you commit.
- I clicked Submit by mistake / with the wrong URL.
	Find an organiser. We can intervene case-by-case but don't count on it - treat the submit button as final.
- Why can't I see my own submission after I submitted it?
	Default privacy. Once locked, the contents (URLs, description) are hidden from the account that submitted them, so people can't compare and re-engineer entries from each other's submitted text. An admin can flip the gate per user if you genuinely need to verify what you sent.
- What goes in the source-code zip?
	The same source you'd hand to a teammate: `backend/`, `frontend/`, configs at the root. **Exclude**: `node_modules`, `.venv`, `.git`, `__pycache__`, `dist`, `build`, `.next`, and any `.env` files. Max 300 MB.
	The Submit page gives you a one-click Cursor prompt that creates the zip with the right excludes - copy, paste in Cursor, done.
- My zip is over the size limit.
	You probably forgot to exclude `node_modules` or `.venv`. Re-zip with the Cursor prompt provided on `/submit` - it sets the right excludes by default.
- Is the Frontend URL optional? Does it count?
	The Level 1 leaderboard score comes from your `/ask` endpoint, but the UI is not optional. A working frontend that includes a graph visualization of the company knowledge is a required deliverable: the human jury (Level 2) opens it and scores usability, the wow factor of the knowledge graph, and the quality of the generated artifacts. A polished, working UI with a clear knowledge graph directly lifts your subjective score - ship one.

07 / Scoring & evaluation

## Scoring & evaluation.

L1 evaluator, L2 human review, pitch finalists.

- How is my company brain scored?
	Three levels, from automated to human.
	- **L1 (automated)**. A hidden question set hits your `/ask`. An LLM judge, anchored to a correction key (the facts each answer must contain), classifies each answer as `correct` (+10), `partial` (+5), `no_answer` (0) or `wrong` (-15). Completeness of the requested data is the primary axis; text quality matters less. Efficiency (calls, data, time, logged via your token) breaks ties. Point values are the working scale, finalized with the reference.
	- **L2 (human jury)**. For the top entries, the jury opens your deployed product and scores three axes: *functioning & usability* of the UI, *wow factor & the knowledge graph*, and the *quality of the generated deliverables* (the docx / pptx / pdf / xlsx artifacts). Each submission carries one shared L2 vote that any judge can read and overwrite. That subjective rating is combined with the objective L1 ranking (70% objective + 30% subjective) for the L2 leaderboard.
	- **L3 (live pitch)**. The top three present their company brain live; the jury picks the final podium from the pitches.
- Why does saying 'I don't have this data' score better than guessing wrong?
	An honest abstention is 0; a fabricated answer is `wrong` and costs points. We weight it this way because a company brain that confidently invents a figure misleads the business, while one that says it can't find the data is at worst inert. If the answer isn't grounded in the API or the documents, decline.
- What's a \`trap\` question?
	A question with a false premise (a customer that doesn't exist, a metric we don't store like a profit margin) or one whose data simply isn't in the sources. The right move is to surface the problem - "no such customer", "that figure isn't in any source" - not to play along. A confident invention is scored `wrong`; an honest "not available" is safe.
- How is efficiency measured?
	Server-side, via your mock-API token. We log how many calls you make, how much data you download and your timing. An agent that searches a long call transcript for the relevant part beats one that downloads the whole thing; a tight loop beats a chatty one. Efficiency is a tie-breaker on completeness, not the primary axis - but at the top it decides places.
- Can I see my L1 score during the event?
	No. The auto-leaderboard is internal during the build day so it doesn't anchor your decisions or distract you. Use the dry-run for private feedback; final results are announced at the end.
- How are pitch finalists picked?
	Top 3 by the combined L2 score (70% objective L1 ranking + 30% the jury's shared subjective vote). They pitch live for a few minutes each, then the jury picks the final podium from the pitches.

08 / Help & escalation

## Help & escalation.

When something breaks, who to ask, what we can fix.

- How do I ask for help during the day?
	Raise a hand - mentors circulate in the room. They debug with you, but they don't write your company brain for you. For non-blocking questions use the chat channel announced at the briefing.
- I forgot my password.
	No self-service reset for the event. Find an organiser, we'll re-issue.
- The Submit page is read-only for me. Why?
	Only participants can submit. Mentors, judges and admins see a preview of the form so they understand what participants fill in - their fields are disabled and the buttons don't fire.
- What if my Railway URL goes down while the evaluator is running?
	The evaluator retries on transient errors, but if the service is down for the entire pass every question hitting it scores `wrong`. Tell an organiser quickly - we can re-run the evaluator once the URL is healthy again. Deploy early so infra problems surface with hours to spare.
- I think the platform itself has a bug.
	Tell an organiser. We have direct access to the logs and the database; most platform-side issues are fixable in minutes during the event.