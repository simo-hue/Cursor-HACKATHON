---
title: "My submission - Coding Agent Hackathon"
source: "https://cursor-hackathon.yellowtest.it/submit"
author:
published:
created: 2026-06-13
description: "Coding Agent Hackathon powered by Cursor - build an agentic company brain over simulated company APIs + RAG. Cursor x Yellow Tech."
tags:
  - "clippings"
---
Your submission

## Submit your company brain.

Drop your endpoint URL, a short description, and the source-code zip. Submission is one-shot: once you click Submit, you cannot edit or replace anything.