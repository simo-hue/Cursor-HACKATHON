---
title: "Cursor credits - Coding Agent Hackathon"
source: "https://cursor-hackathon.yellowtest.it/cursor"
author:
published:
created: 2026-06-13
description: "Coding Agent Hackathon powered by Cursor - build an agentic company brain over simulated company APIs + RAG. Cursor x Yellow Tech."
tags:
  - "clippings"
---
## Your Cursor credits.

Each registered participant gets one Cursor referral code from the event pool. Open its redemption link while logged into Cursor in the same browser to add the credits to your account.

Right account, same browser

Be logged into Cursor with a single-user account (not a Team) in the same browser where you open the link. Redeeming on the wrong account can't be undone.

Free or paid

You can redeem on a Free or paid plan. Credits show in Dashboard > Credits and are applied automatically to your next invoice - they don't activate a plan on their own.

Not for Team plans

Credits only work on individual accounts (Pro / Pro+ / Ultra), never on a Team plan. Some features (Background Agents, Web) need a paid plan.

Active

Assigned 13/06/2026, 10:44:57

Your referral code

`•••••••••••`

Redemption link

`https://cursor.com/referral?code=•••••••••••`

[Open redemption link](https://cursor.com/referral?code=TWOOYVL987P)

Make sure you're logged into Cursor in this browser first. The link stays valid until you click **Redeem** - you can reopen it if something goes wrong.

How to redeem

1. 01
	Sign in to Cursor (right account)
	Open **cursor.com** and sign in with your **individual** account (Free, Pro, Pro+ or Ultra) - **not** a Team account. Use the same browser you'll open the link in.
2. 02
	Open your redemption link
	Click **Open redemption link** above (it carries your referral code). On the page, press **Redeem**. Until you press it the link is reusable, so double-check the account first.
3. 03
	Check Dashboard > Credits
	The credits land in **Dashboard > Credits**. Redeeming adds them to your account but doesn't activate a plan - they apply automatically to your next invoice.
4. 04
	On a Free plan? Start building
	Use the free plan first. When you hit its limit, start a **Pro trial** with a valid payment method (for verification) - the credits are applied once the subscription starts, so you won't be charged while credits remain.

Good to know

Credits do **not** work on a **Team** plan - only on individual Pro / Pro+ / Ultra accounts. Some features (Background Agents, Web) need a paid plan.

Already on a paid plan? The credits show up against your **next invoice**. Free accounts see them applied once a Pro trial or subscription starts.

Don't see the credits after redeeming? Hard-refresh, or log out and back in. Still nothing? Start a checkout on Stripe from your dashboard and confirm they're applied there - then ping an organizer.